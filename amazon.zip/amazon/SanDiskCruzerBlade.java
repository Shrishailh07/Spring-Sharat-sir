class SanDiskCruzerBlade 
     {
    public static void main(String[] mj)
     {
     
String name = "SanDiskCruzerBlade";
System.out.println("Name : "+name);
String Colour = "RED & BLACK";
System.out.println("Colour  : "+Colour );
String Brand = "Sandisk";
System.out.println("Brand : "+Brand );
byte Capacity = 32; 
System.out.println("Storage(GB) : "+Capacity );
String Type = "Flash Drive";
System.out.println("Flash Memory Type : "+Type  );
float Hardware = 2.0f;
System.out.println("Hardware Interface  : "+Hardware );
double Price = 369.00;
System.out.println("Price  : "+Price);
  }
}

/*
Name : SanDiskCruzerBlade
Colour  : RED & BLACK
Brand : Sandisk
Storage(GB) : 32
Flash Memory Type : Flash Drive
Hardware Interface  : 2.0
Price  : 369.0
*/