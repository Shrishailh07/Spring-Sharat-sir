class Iphone
{
	static double price=53.99;	
	static int ram=64;
	
	public static void main(String []args)
{	
	Highlights("Iphone 12 Highlights");
	System.out.println(price);
	System.out.println(ram);

	String color=("BALCK");
	System.out.println(color);
}
	static void Highlights(String name)
{
	System.out.println(name);
}
}