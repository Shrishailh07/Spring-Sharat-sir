class Duracell
   {
    public static void main(String[] mj)
     {
     
byte Battery = 4;
System.out.println("Number of Batteries(AA) : "+Battery);
String Brand = "Duracell";
System.out.println("Brand : "+Brand );
String Cell_Composition = "Alkaline";
System.out.println("Battery Cell Composition : "+Cell_Composition );
short Quantity = 1 ;
System.out.println("Net Quantity : "+Quantity );
float Voltage = 1.2f;
System.out.println("Voltage  : "+Voltage  );
double Weight	= 13.6;
System.out.println("Battery Weight : "+ Weight);
  }
}

/*
C:\Users\Suresh P K\Desktop\java\amazon>javac Duracell.java

C:\Users\Suresh P K\Desktop\java\amazon>java Duracell
Number of Batteries(AA) : 4
Brand : Duracell
Battery Cell Composition : Alkaline
Net Quantity : 1
Voltage  : 1.2
Battery Weight : 13.6

*/