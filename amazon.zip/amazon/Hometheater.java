class Hometheater 
{
	static double price=5666.966;
	
	public static void main(String []args)
{
	ratings("4.4");

	System.out.println(price);

	String warrenty=("1 YEAR");
	System.out.println(warrenty);
}
	static void ratings(String value)
{
	System.out.println(value);
}
}