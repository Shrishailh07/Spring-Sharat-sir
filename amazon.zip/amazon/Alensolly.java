class Alensolly
		{
		static float Discount=(10.50f);
		static double Price=(1500.50);
		static String Sleeves_type=("full_sleeves");
		
		public static void main(String []args)
		{
		System.out.println("Discount");
		System.out.println("Price");
		System.out.println("Sleeves_type");
		
		}
		}