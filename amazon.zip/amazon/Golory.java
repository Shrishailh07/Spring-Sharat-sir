class Golory   
{
	static int pincode=587203; 
	static char size='L';
	
public static void main(String []args)
{
	model("Foraml shirt");	

	System.out.println(pincode);
	System.out.println(size);

	boolean rating=false;
	System.out.println(rating);
	 
	String delivary=("cash on delivary");
	System.out.println("delivary");
}
	static void model(String name)
{
	System.out.println(name);
}	
}