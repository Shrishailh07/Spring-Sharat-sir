class OnePlusNordCE2
       {
       public static void main(String[] mj)
       {
       String name = "OnePlus Nord CE 2 5G";
        System.out.println("Model Name : "+name);
       String Brand = "OnePlus";
       System.out.println("Brand : "+Brand);
       int storage = 128;
        System.out.println("Memory Storage Capacity : "+storage);
       long price = 23999;
       System.out.println("Price : "+price );
       String colour = "Bahamas Blue";
       System.out.println("colour : "+colour );
       String technology = "5G";
       System.out.println("Cellular technology : "+technology);
       short year = 2022;
       System.out.println("Model Year : "+year );
    }
  }
  
/*  
  C:\Users\Suresh P K\Desktop\java\amazon>javac OnePlusNordCE2.java

C:\Users\Suresh P K\Desktop\java\amazon>java OnePlusNordCE2
Model Name : OnePlus Nord CE 2 5G
Brand : OnePlus
Memory Storage Capacity : 128
Price : 23999
colour : Bahamas Blue
Cellular technology : 5G
Model Year : 2022   
  */ 
 