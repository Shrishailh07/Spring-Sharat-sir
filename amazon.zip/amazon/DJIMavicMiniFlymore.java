class DJIMavicMiniFlymore
   {
    public static void main(String[] mj)
     {
     
String name = "DJI Mavic Mini Flymore";
System.out.println("Name : "+ name );
String Brand = "DJI";
System.out.println("Brand : "+ Brand );
String Type = "Remote Control";
System.out.println("Control Type : "+Type);
String Model = "Mavic";
System.out.println("Model name : " + Model);
String colour = "Grey";
System.out.println("colour : "+ colour);
  }
}
/*
Name : DJI Mavic Mini Flymore
Brand : DJI
Control Type : Remote Control
Model name : Mavic
colour : Grey
*/