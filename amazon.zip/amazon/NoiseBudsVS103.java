class NoiseBudsVS103
       {
       public static void main(String[] mj)
       {
       String name = "NoiseBudsVS103";
        System.out.println(" Name : "+name);
       String Brand = "Noise";
       System.out.println("Brand : "+Brand);
       long price = 1299;
       System.out.println("Price : "+price );
       String colour = "Jet Black";
       System.out.println("colour : "+colour );
       String Connector_Type  = "Wireless";
       System.out.println("Connector Type : "+Connector_Type);
       String model = "Buds VS103";
       System.out.println("Model : "+model );
    }
  }
 */
   Name : NoiseBudsVS103
Brand : Noise
Price : 1299
colour : Jet Black
Connector Type : Wireless
Model : Buds VS103
*/