class HITFlyingInsectKiller
  {
static String Name = "Mosquito & Fly Killer Spray";  

static String Brand = "HIT";

static String Scent = "Unscented";

static int Volume = 625;

static String Item ="Instant, Spray";

static float price = 120.5f;
 
public static void main(String[] mj)
{
System.out.println("Name : "+Name );
System.out.println("Brand  : "+Brand );
System.out.println("Scent : "+Scent );
System.out.println("Item Volume(Millilitres) : "+Volume);
System.out.println("Item Form : "+Item );
System.out.println("Price = :"+price);

 }
}

/*
  C:\Users\Suresh P K\Desktop\java\amazon>javac HITFlyingInsectKiller.java

C:\Users\Suresh P K\Desktop\java\amazon>java HITFlyingInsectKiller
Name : Mosquito & Fly Killer Spray
Brand  : HIT
Scent : Unscented
Item Volume(Millilitres) : 625
Item Form : Instant, Spray
Price = :120.5
 */