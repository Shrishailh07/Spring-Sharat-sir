class WhiteshelleCameraLens
     {
    public static void main(String[] mj)
     {
     
String name = "WhiteshelleCameraLens";
System.out.println("Name : "+name);
String Material = "Acrylic";
System.out.println("Material : "+Material);
String Brand = "Whiteshelle";
System.out.println("Brand : "+Brand );
long Capacity = 400; 
System.out.println("Capacity : "+Capacity );
String Colour = "Black";
System.out.println("Colour : "+Colour );
double Price = 160.00;
System.out.println("Price  : "+Price);
  }
}
 /*
C:\Users\Suresh P K\Desktop\java\amazon>javac WhiteshelleCameraLens.java

C:\Users\Suresh P K\Desktop\java\amazon>java WhiteshelleCameraLens
Name : WhiteshelleCameraLens
Material : Acrylic
Brand : Whiteshelle
Capacity : 400
Colour : Black
Price  : 160.0
*/