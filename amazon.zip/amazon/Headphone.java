class Headphone
{
	static String brand=("BOULT");
	
	public static void main(String []args)
{
	price("RS 999");

	System.out.println(brand);

	int pincode=587203;
	System.out.println(pincode);
}
	static void price(String value)
{
	System.out.println(value);
}

}