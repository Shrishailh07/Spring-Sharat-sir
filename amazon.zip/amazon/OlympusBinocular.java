class OlympusBinocular
   {
    public static void main(String[] mj)
     {
     
String name = "OlympusBinocular";
System.out.println("Name : "+ name );
String Brand = "Olympus";
System.out.println("Brand : "+ Brand );
String Water_Resistance = "Water Resistant";
System.out.println("Water Resistance Level : "+Water_Resistance);
String Material = "Plastic";
System.out.println("Material : " + Material);
String colour = "Black";
System.out.println("colour : "+ colour);
  }
}

/*
C:\Users\Suresh P K\Desktop\java\amazon>javac Duracell.java

C:\Users\Suresh P K\Desktop\java\amazon>java Duracell
Number of Batteries(AA) : 4
Brand : Duracell
Battery Cell Composition : Alkaline
Net Quantity : 1
Voltage  : 1.2
Battery Weight : 13.6
  */