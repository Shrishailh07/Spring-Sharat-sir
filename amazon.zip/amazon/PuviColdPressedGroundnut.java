class PuviColdPressedGroundnut
     {
    public static void main(String[] mj)
     {
     
String name = "PuviColdPressedGroundnut";
System.out.println("Name : "+name);
String Material = "Vegetarian";
System.out.println("Material : "+Material);
String Brand = "PUVI";
System.out.println("Brand : "+Brand );
byte volume = 5;
System.out.println("Volume(Litres): "+volume );
float weight = 4.64f;
System.out.println("weight(kg)  : "+weight);
double Price = 195.00;
System.out.println("Price  : "+Price);
  }
}

/*
Name : PuviColdPressedGroundnut
Material : Vegetarian
Brand : PUVI
Volume(Litres): 5
weight(kg)  : 4.64
Price  : 195.0
*/