class BajajDX7 
		{
		public static void main(String []args)
	
		{
		Brand("Ns");
		
		}
		static void Color( String Color)
		{
		System.out.println(Color);
		}
		static void Brand(String Brand)
		{
		System.out.println(Brand);
		}
		
		}
		