class Helmet{

	static	double price=1.091; 
	static	int offer=27;
	static	char size='L';

	public static void main(String []args)
{
	specification("TYPE SPORTYPE");
	System.out.println(price);
	System.out.println(offer);
	System.out.println(size);
	byte review=5;
	System.out.println(review);	

}
	
	static void specification(String name)
{
	System.out.println(name);
		
}
}