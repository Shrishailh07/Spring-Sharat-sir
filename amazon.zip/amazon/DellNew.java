class DellNew
       {
       public static void main(String[] mj)
       {
       String series = "Inspiron 5410";
        System.out.println("series : "+series);
       String Brand = "Dell";
       System.out.println("Brand : "+Brand);
       int storage = 1;
        System.out.println("Storage Capacity(TB) : "+storage);
       long price = 65999;
       System.out.println("Price : "+price );
       String colour = "Platinum Silver";
       System.out.println("colour : "+colour );
       String CPU = "Intel";
       System.out.println("CPU Manufacturer : "+CPU);
       String RAM ="8GB" ;
       System.out.println("RAM : "+RAM );
    }
  }

/*
C:\Users\Suresh P K\Desktop\java\amazon>javac DellNew.java

C:\Users\Suresh P K\Desktop\java\amazon>java DellNew
series : Inspiron 5410
Brand : Dell
Storage Capacity(TB) : 1
Price : 65999
colour : Platinum Silver
CPU Manufacturer : Intel
RAM : 8GB
 */