class Lens
{
	static String model=("NIKON AF AKKOR");
	
	public static void main(String []args)
{
	color("BLACK");

	System.out.println(model);
	
	boolean exchangeOffer=false;
	System.out.println(exchangeOffer);
}
	static void color(String name)
{
	System.out.println(name);
}
}