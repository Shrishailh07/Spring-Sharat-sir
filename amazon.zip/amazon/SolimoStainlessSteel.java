class SolimoStainlessSteel
     {
    public static void main(String[] mj)
     {
     
String name = "SolimoStainlessSteel";
System.out.println("Name : "+name);
String Material = "Stainless Steel";
System.out.println("Material : "+Material);
String Brand = "Amazon Brand - Solimo";
System.out.println("Brand : "+Brand );
byte Capacity = 1; 
System.out.println("Litre : "+Capacity );
String Colour = "Stainless";
System.out.println("Material : "+Colour );
short Style = 3;
System.out.println("Style  : "+Style);
double Price = 749.00;
System.out.println("Price  : "+Price);
  }
}

/*
  C:\Users\Suresh P K\Desktop\java\amazon>javac SolimoStainlessSteel.java

C:\Users\Suresh P K\Desktop\java\amazon>java SolimoStainlessSteel
Name : SolimoStainlessSteel
Material : Stainless Steel
Brand : Amazon Brand - Solimo
Litre : 1
Material : Stainless
Style  : 3
Price  : 749.0
  */